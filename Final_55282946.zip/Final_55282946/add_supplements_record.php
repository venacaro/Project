<?php
require_once('validation.php');


$supplier_id = filter_input(INPUT_POST, 'supplier_id');
$cost_including = filter_input(INPUT_POST, 'cost_including');

// Validate inputs

require_once('database_connection.php');


    // Add the product to the database  
    $query = 'INSERT INTO tblsupplements
                 (Supplier_ID, Cost_incl)
              VALUES
                 (:supplier_id, :cost_including)';
    $statement = $db->prepare($query);
    $statement->bindValue(':supplier_id', $supplier_id);
    $statement->bindValue(':cost_including', $cost_including);
    $statement->execute();
    $statement->closeCursor();
 
    include('supplements.php');


    // Display the Product List page
?>
    
    
    
    
`
