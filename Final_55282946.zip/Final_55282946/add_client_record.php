<?php

require_once('validation.php');

$name = filter_input(INPUT_POST, 'name');
$surname = filter_input(INPUT_POST, 'surname');
$clientid = filter_input(INPUT_POST, 'clientid');
$telephone = filter_input(INPUT_POST, 'telephone');
$email = filter_input(INPUT_POST, 'email');
$ref_id = filter_input(INPUT_POST, 'ref_id', FILTER_VALIDATE_INT);
// Validate inputs

if ($clientid == false || $telephone == false || $email == false || $ref_id == null) {
    $error = "Invalid product data. Check all fields and try again.";
    include('error.php');
} else if(!email_validation($email)) {     

    $error = "invalid email.";
     include('error.php');
 
}   else if(Validate($clientid)==false) {
    
 $error = "invalid id.";
     include('error.php');
    
} else {   
    
    

require_once('database_connection.php');


    // Add the product to the database  
    $query = 'INSERT INTO tblclientinfo
                 (C_name, C_surname, Client_Id, C_Tel_H, C_Email, Reference_ID)
              VALUES
                 (:name, :surname, :clientid, :telephone, :email, :ref_id)';
    $statement = $db->prepare($query);
    $statement->bindValue(':name',$name);
    $statement->bindValue(':surname',$surname);
    $statement->bindValue(':clientid', $clientid);
    $statement->bindValue(':telephone', $telephone);
    $statement->bindValue(':email', $email);
    $statement->bindValue(':ref_id',$ref_id);
    $statement->execute();
    $statement->closeCursor();
 
    include('clients.php');
}

    // Display the Product List page
?>
    
    
    
    
`
