
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>ALTHEALTH</title>

  <!-- Bootstrap core CSS -->
  <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="../css/full-width-pics.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">ALTHEALTH</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
		  

		  
		  
            <a class="nav-link" href="../index.php">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../clients.php">Clients</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../supplier.php">Supplier</a>
          </li>
          <li class="nav-item">
           <a class="nav-link" href="../supplements.php">Supplements</a>
          </li>
		  <li class="nav-item">
            <a class="nav-link" href="../shopping/index.php">Shopping</a>
          </li>
		  <li class="nav-item">
            <a class="nav-link" href="../reports/index.php">Reports</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

    

      <section>
          
        
      <table class="table table-bordered">
          <h1>  List of Report </h1>                  
        <tr>
            <td><p><a href="unpaid_invoices.php"> Unpaid Invoices</a></p></td>
               </tr>
               <tr>
                   <td>    <p><a href="birthdays.php"> Birthdays</a></p></td>
               </tr>
               <tr>
                   <td> <p><a href="min_stock.php"> Minimum stock levels</a></p></td>
                   </tr>
                 </tr>
               <tr>
                   <td> <p><a href="top_10_clients.php"> Top 10 clients 2018-19</a></p></td>
                   
                   </tr> 
                   
                   <tr>
                       
                   <td> <p><a href="purchase_stats.php"> Purchase statistics</a></p></td>
                   
                   </tr> 
                   
                   <tr>
                       
                   <td> <p><a href="client_info_query.php"> Client information query</a></p></td>
                   
                   </tr>

               </form></td>
            </tr>
            
        </table>
        <div>
            
         