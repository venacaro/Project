<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>ALTHEALTH</title>

  <!-- Bootstrap core CSS -->
  <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="../css/full-width-pics.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">ALTHEALTH</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
		  

		  
		  
            <a class="nav-link" href="../index.php">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../clients.php">Clients</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../supplier.php">Supplier</a>
          </li>
          <li class="nav-item">
           <a class="nav-link" href="../supplements.php">Supplements</a>
          </li>
		  <li class="nav-item">
            <a class="nav-link" href="../shopping/index.php">Shopping</a>
          </li>
		  <li class="nav-item">
            <a class="nav-link" href="../reports/index.php">Reports</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

    

<h1>Purchase statistics</h1>

<?php

$link = mysqli_connect("localhost", "root", "", "althealth");
 
// Check connection
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Attempt select query execution
$sql = "SELECT COUNT(*)'NUM OF PURCHASES', monthname(Inv_Date) MONTH 
        FROM tblinv_info  
        WHERE Inv_Date> '2011-12-31' 
        GROUP BY MONTH ORDER BY Month(Inv_Date)";
if($result = mysqli_query($link, $sql)){
    if(mysqli_num_rows($result) > 0){
        echo "<table class='table table-bordered'>";
            echo "<tr>";
                echo "<th>Number of purchases</th>";
                echo "<th>Month</th>";

            echo "</tr>";
        while($row = mysqli_fetch_array($result)){
            echo "<tr>";
                echo "<td>" . $row['NUM OF PURCHASES'] . "</td>";
                echo "<td>" . $row['MONTH'] . "</td>";

            echo "</tr>";
        }
        echo "</table>";
        // Free result set
        mysqli_free_result($result);
    } else{
        echo "No records matching your query were found.";
    }
} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
}
 
// Close connection
mysqli_close($link);
?>
<p><a href="index.php">Back to Menu</a></p>
