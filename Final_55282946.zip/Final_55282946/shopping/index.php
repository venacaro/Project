<?php

session_start();
include('db.php');
$status="";
if (isset($_POST['code']) && $_POST['code']!=""){
$code = $_POST['code'];
$result = mysqli_query($con,"SELECT * FROM `tblsupplements` WHERE `Supplement_id`='$code'");
$row = mysqli_fetch_assoc($result);
$Description = $row['Description'];
$Supplement_id = $row['Supplement_id'];
$Cost_incl = $row['Cost_incl'];


$cartArray = array(
	$code=>array(
	'Description'=>$Description,
	'Supplement_id'=>$Supplement_id,
	'Cost_incl'=>$Cost_incl,
	'quantity'=>1)
);

if(empty($_SESSION["shopping_cart"])) {
	$_SESSION["shopping_cart"] = $cartArray;
	$status = "<div class='box'>Product is added to your cart!</div>";
}else{
	$array_keys = array_keys($_SESSION["shopping_cart"]);
	if(in_array($code,$array_keys)) {
		$status = "<div class='box' style='color:red;'>
		Product is already added to your cart!</div>";	
	} else {
	$_SESSION["shopping_cart"] = array_merge($_SESSION["shopping_cart"],$cartArray);
	$status = "<div class='box'>Product is added to your cart!</div>";
	}

	}
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>ALTHEALTH</title>

  <!-- Bootstrap core CSS -->
  <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="../css/full-width-pics.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">ALTHEALTH</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
		  

		  
		  
            <a class="nav-link" href="../index.php">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../clients.php">Clients</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../supplier.php">Supplier</a>
          </li>
          <li class="nav-item">
           <a class="nav-link" href="../supplements.php">Supplements</a>
          </li>
		  <li class="nav-item">
            <a class="nav-link" href="../shopping/index.php">Shopping</a>
          </li>
		  <li class="nav-item">
            <a class="nav-link" href="../reports/index.php">Reports</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

<body>
<div style="width:700px; margin:50 auto;">



<?php
if(!empty($_SESSION["shopping_cart"])) {
$cart_count = count(array_keys($_SESSION["shopping_cart"]));
?>
<div class="cart_div">
<a href="cart.php"><img src="cart-icon.png" /> Go To Cart<span><?php echo $cart_count; ?></span></a>
</div>
<?php
}

$result = mysqli_query($con,"SELECT * FROM `tblsupplements`");
while($row = mysqli_fetch_assoc($result)){
		echo "<div class='product_wrapper'>
			  <form method='post' action=''>
			  <table class='table table-bordered'>
			  <tr>
			  <td>
			  <input type='hidden' name='code' value=".$row['Supplement_id']." />
				</td> <td>
			  <div class='name'>".$row['Supplement_id']."</div> </td>
		   	 <td>  <div class='price'>$".$row['Cost_incl']."</div> </td>
			  <td> <button type='submit' class='buy'>Buy Now</button> </td>
			  </form>
		   	  </div>";
        }
mysqli_close($con);
?>

<div style="clear:both;"></div>

<div class="message_box" style="margin:10px 0px;">
<?php echo $status; ?>
</div>


</div>
</body>
</html>