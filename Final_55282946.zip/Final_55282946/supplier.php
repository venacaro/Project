<?php

require_once('database_connection.php');



// Get products for selected category
$querySupplierInfo = 'SELECT * FROM tblsupplier_info
                  ORDER BY Supplier_ID';
$statement3 = $db->prepare($querySupplierInfo);
$statement3->execute();
$supplierinformation = $statement3->fetchAll();
$statement3->closeCursor();

   
?> 

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>ALTHEALTH</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/full-width-pics.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">ALTHEALTH</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
		  

		  
		  
            <a class="nav-link" href="index.php">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="clients.php">Clients</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="supplier.php">Supplier</a>
          </li>
          <li class="nav-item">
           <a class="nav-link" href="supplements.php">Supplements</a>
          </li>
		  <li class="nav-item">
            <a class="nav-link" href="shopping/index.php">Shopping</a>
          </li>
		  <li class="nav-item">
            <a class="nav-link" href="reports/index.php">Reports</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

       <h1> List Of Suppliers</h1> 
    
    <section>
        <!-- display a table of products -->
        <aside>
            <p><a href = "add_supplier_record_form.php">Add Record</a></p>
         
        <table>
        <table border="1" cellpadding ="10"class="table">
            <td width="150"Contact Person</td>
            <td width= "200"SupplierTelephone</td>
            <td width="200"SupplierEmail</td>
            
            
            <tr>
                <th>Contact Person</th>
                <th>Supplier Telephone</th>
                <th>Supplier Email</th>
                
            </tr>

            <?php foreach ($supplierinformation as $supplierinfo) : ?>
            <tr>
                <td><?php echo $supplierinfo['Contact_Person']; ?></td>
                <td><?php echo $supplierinfo['Supplier_Tel']; ?></td>
                <td><?php echo $supplierinfo['Supplier_Email']; ?></td>
                 
                </tr>
            <?php endforeach; ?>
        </table>
            
   </section>
</main>
<footer>
    <p>&copy; <?php echo date("Y"); ?>  Althealth, 55282946 Inc.</p>
</footer>
</body>
</html>


