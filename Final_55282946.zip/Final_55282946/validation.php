<?php 
// PHP program to validate email 
  
// Function to validate email using regular expression 
function email_validation($str) { 
    return (!preg_match( 
"^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^", $str)) 
        ? FALSE : TRUE; 
} 
  

 function Validate($idNumber) {
        $correct = true;
        if (strlen($idNumber) !== 13 || !is_numeric($idNumber) ) {
           return false;
        }

        $year = substr($idNumber, 0,2);
        $currentYear = date("Y") % 100;
        $prefix = "19";
        if ($year < $currentYear)
            $prefix = "20";
        $id_year = $prefix.$year;

        $id_month = substr($idNumber, 2,2);
        $id_date = substr($idNumber, 4,2);
        
        

        $fullDate = $id_date. "-" . $id_month. "-" . $id_year;
       
        if (!$id_year == substr($idNumber, 0,2) && $id_month == substr($idNumber, 2,2) && $id_date == substr($idNumber, 4,2)) {
            return false;
        }
     
        $total = 0;
        $count = 0;
        for ($i = 0;$i < strlen($idNumber);++$i)
        {
            $multiplier = $count % 2 + 1;
            $count ++;
            $temp = $multiplier * (int)$idNumber{$i};
            $temp = floor($temp / 10) + ($temp % 10);
            $total += $temp;
        }
        $total = ($total * 9) % 10;

        if ($total % 10 != 0) {
            return false;
        }else{

        return true;
        }
    }
 ?>