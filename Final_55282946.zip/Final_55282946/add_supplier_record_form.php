<?php

require('database_connection.php');
$query = 'SELECT *
          FROM tblsupplier_info';
          
$statement = $db->prepare($query);
$statement->execute();
$suppliers = $statement->fetchAll();
$statement->closeCursor();
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>ALTHEALTH</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/full-width-pics.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">ALTHEALTH</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
		  

		  
		  
            <a class="nav-link" href="index.php">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="clients.php">Clients</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="supplier.php">Supplier</a>
          </li>
          <li class="nav-item">
           <a class="nav-link" href="supplements.php">Supplements</a>
          </li>
		  <li class="nav-item">
            <a class="nav-link" href="shopping/index.php">Shopping</a>
          </li>
		  <li class="nav-item">
            <a class="nav-link" href="reports/index.php">Reports</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

    
<body>
    <header><h1>Supplier</h1></header>

    <main>
        <h1>Add Record</h1>
         
        <form action="add_supplier_record.php" method="post"
              id="add_supplier_record_form">
           
            
              Contact Person<br>
              <input type="text" name="contact_person"><br>
   
              Telephone<br>
              <input type="text" name="supplier_telephone"><br>

              Email<br>
              <input type="text" name="supplier_email"><br>.
            

            <label>&nbsp;</label>
            <input type="submit" value="Submit"><br>
            
        </form>
        <p><a href="index.php">Back to Menu</a></p>
         
    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?>Althealth ,55282946 Inc.</p>
    </footer>
</body>
</html>
