 <?php 
require_once('database_connection.php');



// Get products for selected category
$queryClientInfo = 'SELECT * FROM tblclientinfo
                  ORDER BY Client_id';
$statement3 = $db->prepare($queryClientInfo);
$statement3->execute();
$clientinformation = $statement3->fetchAll();
$statement3->closeCursor();

   
?> 
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>ALTHEALTH</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/full-width-pics.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">ALTHEALTH</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
		  

		  
		  
            <a class="nav-link" href="index.php">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="clients.php">Clients</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="supplier.php">Supplier</a>
          </li>
          <li class="nav-item">
           <a class="nav-link" href="supplements.php">Supplements</a>
          </li>
		  <li class="nav-item">
            <a class="nav-link" href="shopping/index.php">Shopping</a>
          </li>
		  <li class="nav-item">
            <a class="nav-link" href="reports/index.php">Reports</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

    
    <h1> Client Details </h1>
    <section>
        <!-- display a table of products -->
        <aside>
            <p><a href="add_client_record_form.php">Add Record</a></p>
          
        <table>
        <table border="1" cellpadding ="10"class="table">
            <td width= "100"Name</td>
            <td width= "100"Surname</td>
            <td width= "100"ClientID</td>
            <td width="100"TelephoneNumbers</td>
            <td width = "150"Email</td>
            <td width="10"ReferenceID</td>
            
            <tr>
                <th>Name</th>
                <th>Surname</th>
                <th>ClientID</th>
                <th>TelephoneNumbers</th>
                <th>Email</th>
                <th>ReferenceID</th>
                
            </tr>

            <?php foreach ($clientinformation as $clientinfo) : ?>
            <tr>
                <td><?php echo $clientinfo['C_name']; ?></td>
                <td><?php echo $clientinfo['C_surname']; ?></td>
                <td><?php echo $clientinfo['Client_id']; ?></td>
                <td><?php echo $clientinfo['C_Tel_H']; ?></td>
                <td><?php echo $clientinfo['C_Email']; ?></td>
                <td><?php echo $clientinfo['Reference_ID']; ?></td>
                
                </tr>
            <?php endforeach; ?>
        </table>
            
   </section>
</main>
<footer>
    <p>&copy; <?php echo date("Y"); ?> Althealth, 55282946 Inc.</p>
</footer>
</body>
</html>
