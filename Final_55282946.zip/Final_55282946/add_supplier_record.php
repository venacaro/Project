<?php

require_once('validation.php');

$supplier_telephone = filter_input(INPUT_POST, 'supplier_telephone');
$supplier_email = filter_input(INPUT_POST, 'supplier_email');
$contact_person = filter_input(INPUT_POST, 'contact_person');
// Validate inputs

if ($contact_person == false ||   $supplier_telephone == false || $supplier_email == false ) {
    $error = "Invalid product data. Check all fields and try again.";
    include('error.php');
} else if(!email_validation($supplier_email)) {     

    $error = "invalid email.";
     include('error.php');
 
   
} else {   
    
    
require_once('database_connection.php');


    // Add the product to the database  
    $query = 'INSERT INTO tblsupplier_info
                 (Contact_Person, Supplier_Tel, Supplier_Email)
              VALUES
                 (:contact_person, :supplier_telephone, :supplier_email)';
    $statement = $db->prepare($query);
    $statement->bindValue(':contact_person', $contact_person);
    $statement->bindValue(':supplier_telephone', $supplier_telephone);
    $statement->bindValue(':supplier_email', $supplier_email);
    $statement->execute();
    $statement->closeCursor();
 
    include('supplier.php');
}

    // Display the Product List page
?>
    
    
    
    
`


