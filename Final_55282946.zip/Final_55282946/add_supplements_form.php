<?php

require('database_connection.php');
$query = 'SELECT *
          FROM tblsupplements';
          
$statement = $db->prepare($query);
$statement->execute();
$supplements = $statement->fetchAll();
$statement->closeCursor();
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>ALTHEALTH</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/full-width-pics.css" rel="stylesheet">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">ALTHEALTH</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
		  

		  
		  
            <a class="nav-link" href="index.php">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="clients.php">Clients</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="supplier.php">Supplier</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="supplements.php">Supplements</a>
          </li>
		  <li class="nav-item">
            <a class="nav-link" href="shopping/index.php">Shopping</a>
          </li>
		  <li class="nav-item">
            <a class="nav-link" href="reports/index.php">Reports</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

    
<body>
    

    <main>
        <h1>Add New Supplements</h1>
        
        
         <form action="add_supplements_record.php" method="post"
              id="add_supplements_record_form">
               
           
               Supplement ID<br>
               <input type="text" name="supplement_id"><br>
                 
               Description<br>
               <input name="description"><br>    

               Cost Including VAT<br>
               <input type="text" name="cost_including"><br>
             
               Cost Excluding VAT<br>
               <input type="text" name="cost_excluding"><br>
                  
               Min Levels<br>
               <input type="text" name="min_levels"><br>
             
               Current Stock Levels<br>
               <input type="text" name="current_stock_levels"><br>  
             
               Nappi Code<br>
               <input type="text" name="nappi_code"><br> 
              
               Supplier ID<br>
               <select name="supplier_id"><br> 
              
               <?php foreach ($supplements as $supplement) : ?><br
                   <option value="<?php echo $supplement['Supplier_ID']; ?>"><br>
                    <?php echo $supplement['Supplier_ID']; ?><br>
                </option>
               <?php endforeach; ?>
                
                                      
            
            </select><br>
            
            <label>&nbsp;</label>
            <input type="submit" value="Submit"><br>
        </form>
        <p><a href="index.php">Back to Menu</a></p>
    </main>

    <footer>
        <p>&copy; <?php echo date("Y"); ?>Althealth ,55282946 Inc.</p>
    </footer>
</body>
</html>